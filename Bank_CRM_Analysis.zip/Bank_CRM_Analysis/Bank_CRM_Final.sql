CREATE DATABASE BankCRM;

USE BankCRM;



SELECT * FROM bank_churn;
SELECT * FROM customerinfo;
SELECT * FROM creditcard;
SELECT * FROM activecustomer;
SELECT * FROM exitcustomer;
SELECT * FROM gender;
SELECT * FROM geography;

-- Objective Question - 1
SELECT g.GeographyLocation AS region,
       COUNT(*) AS total_customers,
       ROUND(MAX(b.Balance),2) AS maximum_account_balance,
       ROUND(MIN(b.Balance),2) AS minimum_account_balance,
       ROUND(AVG(b.Balance),2) AS average_account_balance
FROM bank_churn b 
JOIN customerinfo c on b.CustomerId = c.CustomerId
JOIN geography g on c.GeographyID = g.GeographyID
GROUP BY g.GeographyLocation
ORDER BY average_account_balance DESC;

-- Objective Question -2 
WITH doj AS (
  SELECT CustomerId, Surname, EstimatedSalary,
         STR_TO_DATE(Bank_DOJ, '%d-%m-%Y') AS doj_date
  FROM customerinfo
)
SELECT CustomerId, Surname, EstimatedSalary, doj_date
FROM doj
WHERE YEAR(doj_date) = (SELECT YEAR(MAX(doj_date)) FROM doj)
  AND MONTH(doj_date) IN (10, 11, 12)
ORDER BY EstimatedSalary DESC
LIMIT 5;


-- Objective Question 3 
SELECT 
    b.CustomerId,
    ROUND(AVG(b.NumOfProducts), 2) AS Avg_Products
FROM bank_churn b
WHERE b.HasCrCard = 1
GROUP BY b.CustomerId;

-- Objective Question - 4
WITH doj AS (
  SELECT CustomerId, STR_TO_DATE(Bank_DOJ, '%d-%m-%Y') AS doj_date
  FROM customerinfo
)
SELECT gd.GenderCategory,
       COUNT(*) AS customers,
       SUM(bc.Exited) AS exited,
       ROUND(SUM(bc.Exited) / COUNT(*), 4) AS churn_rate
FROM bank_churn bc
JOIN customerinfo ci ON ci.CustomerId = bc.CustomerId
JOIN doj d           ON d.CustomerId = ci.CustomerId
JOIN gender gd        ON gd.GenderID = ci.GenderID
WHERE YEAR(d.doj_date) = (SELECT YEAR(MAX(doj_date)) FROM doj)
GROUP BY gd.GenderCategory;


-- Objective Question - 5
SELECT ec.ExitCategory, ROUND(AVG(bc.CreditScore), 2) AS avg_credit_score
FROM bank_churn bc
JOIN exitcustomer ec ON ec.ExitID = bc.Exited
GROUP BY ec.ExitCategory; 

-- Objective Question - 6 
SELECT gd.GenderCategory,
       ROUND(AVG(ci.EstimatedSalary), 2) AS avg_salary,
       SUM(bc.IsActiveMember)            AS active_accounts,
       COUNT(*)                          AS total_customers,
       ROUND(SUM(bc.IsActiveMember) / COUNT(*), 4) AS pct_active
FROM bank_churn bc
JOIN customerinfo ci ON ci.CustomerId = bc.CustomerId
JOIN gender gd        ON gd.GenderID = ci.GenderID
GROUP BY gd.GenderCategory
ORDER BY avg_salary DESC;

-- Objective Question - 7 
WITH segmented AS (
  SELECT *,
    CASE
      WHEN CreditScore < 500 THEN '1: <500 (Poor)'
      WHEN CreditScore < 650 THEN '2: 500-649 (Fair)'
      WHEN CreditScore < 750 THEN '3: 650-749 (Good)'
      ELSE '4: 750+ (Excellent)'
    END AS credit_segment
  FROM bank_churn
)
SELECT credit_segment,
       COUNT(*)                              AS customers,
       SUM(Exited)                           AS exited,
       ROUND(SUM(Exited) / COUNT(*), 4)      AS exit_rate
FROM segmented
GROUP BY credit_segment
ORDER BY exit_rate DESC;

-- Objective Question - 8 
SELECT g.GeographyLocation, COUNT(*) AS active_long_tenure_customers
FROM bank_churn bc
JOIN customerinfo ci ON ci.CustomerId = bc.CustomerId
JOIN geography g      ON g.GeographyID = ci.GeographyID
WHERE bc.IsActiveMember = 1 AND bc.Tenure > 5
GROUP BY g.GeographyLocation
ORDER BY active_long_tenure_customers DESC
LIMIT 1;

-- Objective Question- 9
SELECT cc.Category,
       COUNT(*)                          AS customers,
       SUM(bc.Exited)                    AS exited,
       ROUND(SUM(bc.Exited) / COUNT(*), 4) AS churn_rate
FROM bank_churn bc
JOIN creditcard cc ON cc.CreditID = bc.HasCrCard
GROUP BY cc.Category;

-- Objective Question - 10
SELECT NumOfProducts, COUNT(*) AS customer_count
FROM bank_churn
WHERE Exited = 1
GROUP BY NumOfProducts
ORDER BY customer_count DESC
LIMIT 1; 

-- Objective Question - 11 
WITH doj AS (
  SELECT CustomerId, STR_TO_DATE(Bank_DOJ, '%d-%m-%Y') AS doj_date
  FROM customerinfo
)
-- yearly trends
SELECT YEAR(doj_date) AS join_year, COUNT(*) AS customers_joined
FROM doj GROUP BY join_year ORDER BY join_year;
-- monthly trends
SELECT MONTH(doj_date) AS join_month, COUNT(*) AS customers_joined
FROM doj GROUP BY join_month ORDER BY join_month;

-- Objective Question - 12 
SELECT NumOfProducts,
       COUNT(*)                    AS exited_customers,
       ROUND(AVG(Balance), 2)      AS avg_balance,
       ROUND(STDDEV(Balance), 2)   AS stddev_balance
FROM bank_churn
WHERE Exited = 1
GROUP BY NumOfProducts
ORDER BY NumOfProducts;

-- Objective Question - 13 (IQR Method)
WITH remained AS (
  SELECT Balance,
         NTILE(4) OVER (ORDER BY Balance) AS quartile
  FROM bank_churn
  WHERE Exited = 0
),
bounds AS (
  SELECT
    MAX(CASE WHEN quartile = 1 THEN Balance END) AS q1,
    MAX(CASE WHEN quartile = 3 THEN Balance END) AS q3
  FROM (
    SELECT Balance, NTILE(4) OVER (ORDER BY Balance) AS quartile
    FROM bank_churn WHERE Exited = 0
  ) x
)
SELECT bc.CustomerId, bc.Balance
FROM bank_churn bc, bounds b
WHERE bc.Exited = 0
  AND (bc.Balance < b.q1 - 1.5 * (b.q3 - b.q1)
       OR bc.Balance > b.q3 + 1.5 * (b.q3 - b.q1));
       
-- Objective Question - 15
SELECT g.GeographyLocation,
       gd.GenderCategory,
       ROUND(AVG(ci.EstimatedSalary), 2) AS avg_income,
       RANK() OVER (PARTITION BY g.GeographyLocation ORDER BY AVG(ci.EstimatedSalary) DESC) AS income_rank
FROM customerinfo ci
JOIN geography g ON g.GeographyID = ci.GeographyID
JOIN gender gd    ON gd.GenderID = ci.GenderID
GROUP BY g.GeographyLocation, gd.GenderCategory
ORDER BY g.GeographyLocation, income_rank;

-- Objective Question - 16
SELECT
  CASE
    WHEN Age BETWEEN 18 AND 30 THEN '18-30'
    WHEN Age BETWEEN 31 AND 50 THEN '30-50'
    ELSE '50+'
  END AS age_bracket,
  ROUND(AVG(bc.Tenure), 2) AS avg_tenure,
  COUNT(*)                 AS exited_customers
FROM bank_churn bc
JOIN customerinfo ci ON ci.CustomerId = bc.CustomerId
WHERE bc.Exited = 1
GROUP BY age_bracket
ORDER BY age_bracket;

-- Objective Question - 17
SELECT
  bc.Exited,
  (COUNT(*) * SUM(ci.EstimatedSalary * bc.Balance) - SUM(ci.EstimatedSalary) * SUM(bc.Balance))
  /
  ( SQRT(COUNT(*) * SUM(POWER(ci.EstimatedSalary,2)) - POWER(SUM(ci.EstimatedSalary),2))
  * SQRT(COUNT(*) * SUM(POWER(bc.Balance,2))        - POWER(SUM(bc.Balance),2)) )
  AS pearson_r
FROM bank_churn bc
JOIN customerinfo ci ON ci.CustomerId = bc.CustomerId
GROUP BY bc.Exited;

-- Objective Question - 18
SELECT
  (COUNT(*) * SUM(ci.EstimatedSalary * bc.CreditScore) - SUM(ci.EstimatedSalary) * SUM(bc.CreditScore))
  /
  ( SQRT(COUNT(*) * SUM(POWER(ci.EstimatedSalary,2)) - POWER(SUM(ci.EstimatedSalary),2))
  * SQRT(COUNT(*) * SUM(POWER(bc.CreditScore,2))     - POWER(SUM(bc.CreditScore),2)) )
  AS pearson_r
FROM bank_churn bc
JOIN customerinfo ci ON ci.CustomerId = bc.CustomerId;

-- Objective Question - 19
WITH segmented AS (
  SELECT *,
    CASE
      WHEN CreditScore < 500 THEN '<500'
      WHEN CreditScore < 650 THEN '500-649'
      WHEN CreditScore < 750 THEN '650-749'
      ELSE '750+'
    END AS credit_bucket
  FROM bank_churn
)
SELECT credit_bucket,
       SUM(Exited) AS churned_customers,
       RANK() OVER (ORDER BY SUM(Exited) DESC) AS churn_rank
FROM segmented
GROUP BY credit_bucket;

-- Objective Question - 20
WITH age_buckets AS (
  SELECT bc.HasCrCard,
    CASE
      WHEN ci.Age BETWEEN 18 AND 30 THEN '18-30'
      WHEN ci.Age BETWEEN 31 AND 50 THEN '30-50'
      ELSE '50+'
    END AS age_bucket
  FROM bank_churn bc
  JOIN customerinfo ci ON ci.CustomerId = bc.CustomerId
),
bucket_counts AS (
  SELECT age_bucket, SUM(HasCrCard) AS cc_count
  FROM age_buckets
  GROUP BY age_bucket
)
SELECT age_bucket, cc_count,
       (SELECT AVG(cc_count) FROM bucket_counts) AS avg_cc_per_bucket
FROM bucket_counts
WHERE cc_count < (SELECT AVG(cc_count) FROM bucket_counts);

-- Objective Question - 21 
SELECT g.GeographyLocation,
       SUM(bc.Exited)                    AS churned_customers,
       ROUND(AVG(bc.Balance), 2)         AS avg_balance,
       RANK() OVER (ORDER BY SUM(bc.Exited) DESC) AS churn_rank
FROM bank_churn bc
JOIN customerinfo ci ON ci.CustomerId = bc.CustomerId
JOIN geography g      ON g.GeographyID = ci.GeographyID
GROUP BY g.GeographyLocation
ORDER BY churn_rank;

-- Objective Question - 22 
SELECT CustomerId, Surname,
       CONCAT(CustomerId, '_', Surname) AS CustomerID_Surname
FROM customerinfo;

-- Objective Question - 23
SELECT bc.*,
       (SELECT ec.ExitCategory FROM ExitCustomer ec WHERE ec.ExitID = bc.Exited) AS ExitCategory
FROM bank_churn bc;

-- Objective Question - 25
SELECT bc.CustomerId, ci.Surname,
       CASE WHEN bc.IsActiveMember = 1 THEN 'Active' ELSE 'Inactive' END AS active_status
FROM bank_churn bc
JOIN customerinfo ci ON ci.CustomerId = bc.CustomerId
WHERE ci.Surname LIKE '%on';
       
-- Objective Question - 26
SELECT CustomerId, IsActiveMember, Exited
FROM bank_churn
WHERE Exited = 1 AND IsActiveMember = 1;

-- Subjective Question - 9
SELECT
  CASE WHEN ci.Age BETWEEN 18 AND 30 THEN '18-30'
       WHEN ci.Age BETWEEN 31 AND 50 THEN '30-50'
       ELSE '50+' END                    AS age_bucket,
  gd.GenderCategory,
  g.GeographyLocation,
  cc.Category                            AS credit_card_status,
  COUNT(*)                               AS customers,
  ROUND(AVG(bc.Balance), 2)              AS avg_balance,
  ROUND(SUM(bc.Exited) / COUNT(*), 4)    AS churn_rate
FROM bank_churn bc
JOIN customerinfo ci ON ci.CustomerId = bc.CustomerId
JOIN gender gd        ON gd.GenderID = ci.GenderID
JOIN geography g      ON g.GeographyID = ci.GeographyID
JOIN creditcard cc    ON cc.CreditID = bc.HasCrCard
GROUP BY age_bucket, gd.GenderCategory, g.GeographyLocation, cc.Category
ORDER BY churn_rate DESC;

-- Subjective Question - 14
ALTER TABLE bank_churn
CHANGE HasCrCard Has_creditcard INT;

